package ch.usi.dag.disl.staticcontext.uid;

/**
 * This class has been deprecated in favor of the {@link RandomMethodUid} and
 * will be eliminated in future.
 */
@Deprecated
public class UniqueMethodId extends RandomMethodUid {

    // constructor for static context
    public UniqueMethodId () {
        super ();
    }

}
